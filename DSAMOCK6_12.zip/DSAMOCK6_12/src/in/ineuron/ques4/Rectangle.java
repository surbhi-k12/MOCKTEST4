package in.ineuron.ques4;

public class Rectangle implements Drawable {

	public void draw() {
		System.out.println("Draw a Rectangle");
	}
}
