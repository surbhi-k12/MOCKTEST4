package in.ineuron.ques4;

public class Test {

	public static void main(String[] args) {
		Drawable c=new Circle();
		Drawable r=new Rectangle();
		
		c.draw();
		r.draw();
		

	}

}
