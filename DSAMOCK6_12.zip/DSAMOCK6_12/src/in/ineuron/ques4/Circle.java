package in.ineuron.ques4;

public class Circle implements Drawable {

	public void draw() {
		System.out.println("Draw a circle");
	}
}
